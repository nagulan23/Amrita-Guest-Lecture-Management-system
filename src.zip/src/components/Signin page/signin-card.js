import "./signin-card.css";
import React, { Component,useContext } from "react";
import firebaseAuth from '../../provider/AuthProvider'

/*function HandleSubmit(e){
  console.log("Handle function")
  e.preventDefault()
  const {handleSignup,handleSignin,inputs,setInputs,errors} = useContext(firebaseAuth)
  if(handleSignin()){
    //this.props.changePage();
    console.log("HandleSgnin function")
  }
};

function HandleSubmit() {
  const {handleSignup,handleSignin,inputs,setInputs,errors} = useContext(firebaseAuth)
  const handleSubmit = (e) => {
    e.preventDefault()
    if(handleSignin()){
      //this.props.changePage();
      console.log("HandleSgnin function")
    }
  }
  
  return (handleSubmit);
}*/
class Signin_Card extends Component {

  constructor() {
    super();
    this.handleSubmit = this.handleSubmit.bind(this); // <-- add this line
  }

  handleSubmit (e){
    e.preventDefault()
    //const {handleSignup,handleSignin,inputs,setInputs,errors} = firebaseAuth
    console.log("handleSignup")
    if(() => this.handleSignin()){
      this.props.changePage()
      console.log("HandleSgnin function")
    }
  }

  login() {
    document.getElementById("login").style.left = "50px";
    document.getElementById("register").style.left = "450px";
    document.getElementById("btn").style.left = "0px";
    document.getElementById("toggle-btn1").style.color= "#ffe957";
    document.getElementById("toggle-btn2").style.color= "#282c34";
  }
  register() {
    document.getElementById("login").style.left = "-400px";
    document.getElementById("register").style.left = "50px";
    document.getElementById("btn").style.left = "110px";
    document.getElementById("toggle-btn2").style.color= "#ffe957";
    document.getElementById("toggle-btn1").style.color= "#282c34";
  }

  state = {};
  render() {
    return (
      <div>
        <link
          rel="stylesheet"
          type="text/css"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css"
        />
        <div className="App">
          <div class="hero">
            <div className="form-box">
              <div className="button-box">
                <div id="btn"></div>
                <button
                  type="button"
                  id="toggle-btn1"
                  className="toggle-btn1"
                  onClick={this.login.bind(this)}
                >
                  Sign In
                </button>
                <button
                  type="button"
                  id="toggle-btn2"
                  className="toggle-btn2"
                  onClick={this.register.bind(this)}
                >
                  {" "}
                  Sign Up
                </button>
              </div>
              <form id="login" className="input-group" onSubmit={this.handleSubmit}>
                {/* <input type="text" className="input-field" placeholder="Mail-Id" required/>
            <input type="text" className="input-field" placeholder="Password" required/> */}
                <div className="inputwithIcon">
                  <input type="text" placeholder="Mail-Id" />
                  <i
                    type="icon"
                    class="fa fa-user-circle-o fa-lg fa-fw"
                    aria-hidden="true"
                  ></i>
                </div>
                <div class="inputwithIcon">
                  <input type="text" placeholder="Password" />
                  <i
                    type="icon"
                    className="inputwithiconii"
                    class="fa fa-lock fa-lg fa-fw"
                    aria-hidden="true"
                  ></i>
                </div>
                <input type="checkbox" className="check-box1"></input>
                <span1 >Forgot Password?</span1>
                <button type="submit" className="submit-btn">
                  Login
                </button>
              </form>
              <form id="register" className="input-group">
                {/* <input type="text" className="input-field" placeholder="Mail-Id" required/>
            <input type="text" className="input-field" placeholder="Password" required/> 
            <input type="text" className="input-field" placeholder="Re-Password" required/>*/}

                <div class="inputwithIcon">
                  <input type="text" placeholder="Mail-Id" />
                  <i
                    class="fa fa-user-circle-o fa-lg fa-fw"
                    aria-hidden="true"
                  ></i>
                </div>
                <div class="inputwithIcon">
                  <input type="text" placeholder="Password" />
                  <i
                    type="icon"
                    class="fa fa-lock fa-lg fa-fw"
                    aria-hidden="true"
                  ></i>
                </div>
                <div class="inputwithIcon">
                  <input type="text" placeholder="Re-Password" />
                  <i
                    type="icon"
                    class="fa fa-key fa-lg fa-fw"
                    aria-hidden="true"
                  ></i>
                </div>
                <input type="checkbox" className="check-box"></input>
                <span>I agree to terms and conditions*</span>
                <button type="submit" className="submit-btn">
                  Register
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Signin_Card;
