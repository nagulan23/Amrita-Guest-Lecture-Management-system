import React, { Component } from "react";
import "./lecture_card.css";

class Lecture_card extends Component {
  state = {};
  render() {
    return (
      <div className="container">
        <div className="image-container">
          <img
            src="https://img.freepik.com/free-vector/music-event-poster-template-with-abstract-shapes_1361-1316.jpg?size=626&ext=jpg"
            className="short-image"
          />
        </div>
        <div className="below-container">
          <p className="title">Music Lecture</p>
          <p className="content">19/2 18:00 - 20/2/18:00</p>
          <p className="content">Amriteswari Hall</p>
        </div>
      </div>
    );
  }
}

export default Lecture_card;
