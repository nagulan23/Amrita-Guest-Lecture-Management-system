import React, { Component } from "react";
import "./home.css";
import logo from "../../assets/amrita-logo.png";
import OngoingLecture from "./ongoingLecture";

class Home extends Component {
  state = {};
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <div className="logo-name">
            <img src={logo} alt="logo" className="image" />
            <h className="highlight">A</h>mrita
            <h className="highlight"> G</h>uest
            <h className="highlight"> L</h>ecture
            <h className="highlight"> M</h>anagement
            <h className="highlight"> S</h>ystem
          </div>
          <button className="profile">CB.EN.U4CSE18XXX</button>
        </header>
        <div className="body">
          <OngoingLecture />
        </div>
      </div>
    );
  }
}

export default Home;
