import React, { Component } from "react";
import "./ongoingLecture.css";
import Lecture_card from "./lecture_card";

class OngoingLecture extends Component {
  state = {};
  render() {
    return (
      <div className="container">
        <div className="heading">Ongoing Lectures</div>
        <div className="underline"></div>
        <div className="row-scroll">
          <Lecture_card />
          <Lecture_card />
        </div>
      </div>
    );
  }
}

export default OngoingLecture;
